namespace ClaimSettlement.Domain;

public sealed record ClaimRequest(string PolicyNumber, decimal ClaimAmount, int PropertyAgeYears);
public sealed record SettlementDecision(string PolicyNumber, bool IsApproved, string StatusReason);
public sealed record PolicyDetails(decimal CoverageLimit, bool IsActive);

public static class SettlementRules
{
    public const decimal NewerPropertyThreshold = 3000;
    public const decimal OlderPropertyThreshold = 1000;
    public const int PropertyAgeBoundary = 30;

    public static SettlementDecision Evaluate(ClaimRequest claim, PolicyDetails policy)
    {        
        ArgumentNullException.ThrowIfNull(claim);
        ArgumentNullException.ThrowIfNull(policy);
        if (!policy.IsActive)
            return new(claim.PolicyNumber, false, "Policy Inactive");

        if (claim.ClaimAmount > policy.CoverageLimit)
            return new(claim.PolicyNumber, false, "Coverage Limit Exceeded");

        var threshold = claim.PropertyAgeYears <= PropertyAgeBoundary
            ? NewerPropertyThreshold
            : OlderPropertyThreshold;

        if (claim.ClaimAmount > threshold)
            return new(claim.PolicyNumber, false, "Adjuster Review Required");

        return new(claim.PolicyNumber, true, "Auto-Settled");
    }
}
