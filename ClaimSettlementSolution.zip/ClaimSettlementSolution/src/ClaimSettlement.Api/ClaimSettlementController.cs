using ClaimSettlement.Application;
using ClaimSettlement.Domain;
using Microsoft.AspNetCore.Mvc;
namespace ClaimSettlement.Api;

[ApiController]
public sealed class ClaimSettlementController(ClaimSettlementService settlementService) : ControllerBase
{
    [HttpPost]
    [Route("claim-settlement")]
    [ProducesResponseType(typeof(SettlementDecision), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    public async Task<ActionResult<SettlementDecision>> Evaluate(
        [FromBody] ClaimRequest? request,
        CancellationToken cancellationToken)
    {
        if (request is null)
            return BadRequest(new { error = "Request body is required." });

        var errors = new Dictionary<string, string[]>();
        if (string.IsNullOrWhiteSpace(request.PolicyNumber))
            errors[nameof(request.PolicyNumber)] = ["PolicyNumber must not be blank."];
        if (request.ClaimAmount <= 0)
            errors[nameof(request.ClaimAmount)] = ["ClaimAmount must be greater than zero."];
        if (request.PropertyAgeYears < 0)
            errors[nameof(request.PropertyAgeYears)] = ["PropertyAgeYears must not be negative."];
        if (errors.Count > 0)
            return BadRequest(errors);

        try
        {
            return Ok(await settlementService.EvaluateAsync(request, cancellationToken));
        }
        catch (PolicyNotFoundException)
        {
            return NotFound(new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Policy not found",
                Detail = "No policy was found for the supplied policy number."
            });
        }
        catch (PolicyDependencyException)
        {
            return StatusCode(StatusCodes.Status502BadGateway, new ProblemDetails
            {
                Status = StatusCodes.Status502BadGateway,
                Title = "Policy service unavailable",
                Detail = "The claim could not be evaluated because the policy service failed."
            });
        }
    }
}
