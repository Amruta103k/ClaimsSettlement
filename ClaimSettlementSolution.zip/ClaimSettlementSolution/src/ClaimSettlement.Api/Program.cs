using ClaimSettlement.Application;
using ClaimSettlement.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddProblemDetails();
builder.Services.AddControllers();
builder.Services.AddSingleton<IDecisionRepository, InMemoryDecisionRepository>();
builder.Services.AddScoped<ClaimSettlementService>();

var policyBaseAddress = builder.Configuration["PolicyAdmin:BaseAddress"];
if (!Uri.TryCreate(policyBaseAddress, UriKind.Absolute, out var policyUri) ||
    (policyUri.Scheme != Uri.UriSchemeHttp && policyUri.Scheme != Uri.UriSchemeHttps))
{
    throw new InvalidOperationException("Configuration 'PolicyAdmin:BaseAddress' must be an absolute HTTP(S) URL.");
}

builder.Services.AddHttpClient<IPolicyAdminClient, PolicyAdminHttpClient>(client =>
{
    client.BaseAddress = policyUri;
    client.Timeout = TimeSpan.FromSeconds(5);
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    _ = app.UseSwagger();
    _ = app.UseSwaggerUI();
}

app.UseExceptionHandler();
app.MapControllers();
app.Run();

public partial class Program { }
