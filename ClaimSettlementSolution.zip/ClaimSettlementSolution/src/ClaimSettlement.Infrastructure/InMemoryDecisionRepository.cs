using System.Collections.Concurrent;
using ClaimSettlement.Application;
using ClaimSettlement.Domain;

namespace ClaimSettlement.Infrastructure;

public sealed class InMemoryDecisionRepository : IDecisionRepository
{
    private readonly ConcurrentQueue<SettlementDecision> _decisions = new();

    public Task RecordAsync(SettlementDecision decision, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _decisions.Enqueue(decision);
        return Task.CompletedTask;
    }

    public IReadOnlyList<SettlementDecision> GetAll() => _decisions.ToArray();
}
