using ClaimSettlement.Application;
using ClaimSettlement.Domain;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace ClaimSettlement.Infrastructure;

public sealed class PolicyAdminHttpClient(HttpClient httpClient) : IPolicyAdminClient
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<PolicyDetails?> GetPolicyAsync(string policyNumber, CancellationToken cancellationToken)
    {
        using var response = await httpClient.GetAsync(
            $"policies/{Uri.EscapeDataString(policyNumber)}", cancellationToken);

        if (response.StatusCode == HttpStatusCode.NotFound)
            throw new PolicyNotFoundException(policyNumber);

        if (!response.IsSuccessStatusCode)
            throw new PolicyDependencyException($"Policy service returned HTTP {(int)response.StatusCode}.");

        try
        {
            var policy = await response.Content.ReadFromJsonAsync<PolicyDetails>(JsonOptions, cancellationToken);
            if (policy is null)
                throw new JsonException("Policy response was empty.");
            return policy;
        }
        catch (Exception ex)
        {
            throw new PolicyDependencyException("Policy service returned an invalid response.", ex);
        }
    }
}
