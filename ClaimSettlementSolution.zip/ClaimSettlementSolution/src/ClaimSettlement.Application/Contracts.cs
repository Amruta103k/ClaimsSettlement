using ClaimSettlement.Domain;

namespace ClaimSettlement.Application;

public interface IPolicyAdminClient
{
    Task<PolicyDetails?> GetPolicyAsync(string policyNumber, CancellationToken cancellationToken);
}

public interface IDecisionRepository
{
    Task RecordAsync(SettlementDecision decision, CancellationToken cancellationToken);
    IReadOnlyList<SettlementDecision> GetAll();
}

public sealed class PolicyNotFoundException(string policyNumber)
    : Exception($"Policy '{policyNumber}' was not found.");

public sealed class PolicyDependencyException(string message, Exception? innerException = null)
    : Exception(message, innerException);

public sealed class ClaimSettlementService(
    IPolicyAdminClient policyClient,
    IDecisionRepository decisionRepository)
{
    public async Task<SettlementDecision> EvaluateAsync(ClaimRequest claim, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        PolicyDetails? policy;
        try
        {
            policy = await policyClient.GetPolicyAsync(claim.PolicyNumber, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (PolicyNotFoundException)
        {
            throw;
        }
        catch (Exception ex)
        {
            throw new PolicyDependencyException("The policy service could not be reached or returned an invalid response.", ex);
        }

        if (policy is null)
            throw new PolicyNotFoundException(claim.PolicyNumber);

        cancellationToken.ThrowIfCancellationRequested();
        var decision = SettlementRules.Evaluate(claim, policy);
        cancellationToken.ThrowIfCancellationRequested();
        await decisionRepository.RecordAsync(decision, cancellationToken);
        return decision;
    }
}
