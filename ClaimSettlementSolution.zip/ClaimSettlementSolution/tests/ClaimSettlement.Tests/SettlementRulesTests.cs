using ClaimSettlement.Domain;

namespace ClaimSettlement.Tests;

public sealed class SettlementRulesTests
{
    [Fact]
    public void ActiveCoveredClaimWithinThreshold_IsAutoSettled()
    {
        var result = SettlementRules.Evaluate(new("POL-1", 2500m, 10), new(10000m, true));
        Assert.Equal(new SettlementDecision("POL-1", true, "Auto-Settled"), result);
    }

    [Fact]
    public void InactivePolicyTakesPrecedenceOverOtherFailures()
    {
        var result = SettlementRules.Evaluate(new("POL-1", 5000m, 40), new(1000m, false));
        Assert.Equal("Policy Inactive", result.StatusReason);
        Assert.False(result.IsApproved);
    }

    [Fact]
    public void CoverageLimitTakesPrecedenceOverThresholdReview()
    {
        var result = SettlementRules.Evaluate(new("POL-1", 3500m, 10), new(3000m, true));
        Assert.Equal("Coverage Limit Exceeded", result.StatusReason);
    }

    [Fact]
    public void OlderPropertyUsesOneThousandThreshold()
    {
        var result = SettlementRules.Evaluate(new("POL-1", 1001m, 31), new(10000m, true));
        Assert.False(result.IsApproved);
        Assert.Equal("Adjuster Review Required", result.StatusReason);
    }

    [Fact]
    public void BoundaryValuesAreInclusive()
    {
        Assert.True(SettlementRules.Evaluate(new("POL-1", 3000m, 30), new(3000m, true)).IsApproved);
        Assert.True(SettlementRules.Evaluate(new("POL-2", 1000m, 31), new(1000m, true)).IsApproved);
    }
}
