using ClaimSettlement.Application;
using ClaimSettlement.Domain;

namespace ClaimSettlement.Tests;

public sealed class ClaimSettlementServiceTests
{
    [Fact]
    public async Task SuccessfulPolicyLookupRecordsDecision()
    {
        var repository = new TestRepository();
        var service = new ClaimSettlementService(new FakePolicyClient(new(10000m, true)), repository);

        var decision = await service.EvaluateAsync(new("POL-1", 500m, 5), CancellationToken.None);

        Assert.True(decision.IsApproved);
        _ = Assert.Single(repository.Decisions);
    }

    [Fact]
    public async Task MissingPolicyDoesNotRecordDecision()
    {
        var repository = new TestRepository();
        var service = new ClaimSettlementService(new FakePolicyClient(null), repository);

        _ = await Assert.ThrowsAsync<PolicyNotFoundException>(() =>
            service.EvaluateAsync(new("MISSING", 500m, 5), CancellationToken.None));
        Assert.Empty(repository.Decisions);
    }

    [Fact]
    public async Task CancellationIsPropagatedAndDoesNotRecordDecision()
    {
        using var cts = new CancellationTokenSource();
        cts.Cancel();
        var repository = new TestRepository();
        var service = new ClaimSettlementService(new FakePolicyClient(new(10000m, true)), repository);

        _ = await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            service.EvaluateAsync(new("POL-1", 500m, 5), cts.Token));
        Assert.Empty(repository.Decisions);
    }

    private sealed class FakePolicyClient(PolicyDetails? policy) : IPolicyAdminClient
    {
        public Task<PolicyDetails?> GetPolicyAsync(string policyNumber, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return Task.FromResult(policy);
        }
    }

    private sealed class TestRepository : IDecisionRepository
    {
        public List<SettlementDecision> Decisions { get; } = [];
        public Task RecordAsync(SettlementDecision decision, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Decisions.Add(decision);
            return Task.CompletedTask;
        }
        public IReadOnlyList<SettlementDecision> GetAll() => Decisions;
    }
}
